

export default function Home() {
  return (
    <div className="text-3xl">
      Hello
    </div>
  );
}
